/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poepartone;

/**
 *
 * @author Student
 */
public class Login {
   private final String username;
   private final String password;
   private final String firstName;
   private final String lastName;
   private final String cellPhone;
   
   public Login (String usern, String pass, String fname,String lname, String cPhone) {
        this.username = usern;
        this.password = pass;
        this.firstName = fname;
        this.lastName = lname;
        this.cellPhone = cPhone;
   }
   public boolean checkUsername(){
           return username  != null && !username.contains("_") && username.length()<= 5;
   }
   //
   public boolean checkPassword(){
       boolean hasUpper = false;
       boolean hasLower = false;
       boolean hasDigit = false;
       boolean hasSpecial = false;
       
       if (password == null || password.length()< 8){
           return false;
           
       }
       for (char c : password.toCharArray ()){
           if (Character.isUpperCase(c)){
               hasUpper = true;
           } else if ( Character.isLowerCase(c)){
               hasLower = true;
           } else if ( Character.isDigit(c)){
               hasDigit = true;
           } else if (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c)){
               hasSpecial = true;          
           }
           return hasUpper && hasLower && hasDigit && hasSpecial;
   }
       return false;
    
         

    /**
     *
     * @return
     */
   }
    public boolean checkCellPhoneNumber(){
        if(cellPhone == null) {
            return false;
        }
        String cleaned = cellPhone.trim().replaceAll("[\\s-]","");
           
        return cleaned.matches("\\+27\\d{9}");
        }   
    public boolean loginUser(String enterUsername, String enterPassword ){          
    
 return this.username.equals(enterUsername) &&
        this.password.equals(enterPassword);       
           }
    public String returnLoginStatus (boolean loginSuccess){
        if (loginSuccess) {
            return "Welcome" + firstName + "" + lastName + "it is great to see you again.";
        }else {
            return" Username or password incorrect, please try again.";
        }
    }
        public String getUsername(){return username;}
        public String getPassword(){return password;}
        public String getFirstName(){return firstName;}
        public String getLastName(){return lastName;}
        public String getCellPhone(){return cellPhone;}      

    public boolean checkUserName(String kyl_1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean checkCellPhoneNumber(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean checkPasswordComplexity(String chsecke99) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
        }
         
       

           

