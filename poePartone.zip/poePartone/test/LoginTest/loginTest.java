/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package LoginTest;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import poepartone.Login;

/**
 *
 * @author Student
 */
public class loginTest {
     private final Login login = new Login(
     "kyl_1",
     "Ch&&sec@ke99!",
     "Kyle",
     "Smith",
     "+27838968976"       
     );
     @Test
     public void testUsernameCorrectlyFormatted(){
         boolean isValid = login.checkUserName("kyl_1");
         assertTrue(isValid);
     }
     @Test
     public void testUsernameIncorrectlyFormatted(){
         boolean isVaild = login.checkUserName("kyle!!!!!!!");
         assertFalse(isVaild);
     }
     @Test
     public void testPasswordMeetsComplexity(){
         @SuppressWarnings("unused")
         boolean isValid = login.checkPasswordComplexity("Ch&&sec@ke99!");
     }
    @Test
    public void testPasswordDoesNotMeetsComplexity(){
        boolean isValid = login.checkPasswordComplexity("password");
        assertFalse(isValid);
     }
    @Test
    public void testCellPhoneNumberCorrect(){
        boolean isValid = login.checkCellPhoneNumber("+27838968976");
        assertTrue (isValid);
    }
    @Test
    public void testCellPhoneNumberIncorrect(){
        boolean isValid = login.checkCellPhoneNumber("08966553");
        assert(isValid);
    }
    @Test
    public void testLoginSuccessful(){
        boolean success = login.loginUser("kyl_1","Ch&&sec@ke99!");
        assertTrue(success);
    }
    @Test
    public void testLoginFailed(){
        boolean success = login.loginUser ("wrong_user","wrongpass");
        assertFalse(success);
    }
    
         
     }

